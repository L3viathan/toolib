from distutils.core import setup

setup(name='toolib',
      version='0.1',
      author='L3viathan',
      author_email='git@l3vi.de',
      url='https://github.com/L3viathan/toolib',
      py_modules=['toolib'],
      )
